package com.wipro.school.main;

public class MainClass {
	
}
