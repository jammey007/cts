package com.wipro.school.service;

import java.sql.Date;
import java.util.List;

import com.wipro.school.bean.AluminiBean;
import com.wipro.school.bean.EmployeeBean;
import com.wipro.school.bean.StudentBean;

public interface AdminServiceInterface {
	public boolean adminFinder(String userName);

	public boolean studentFinder(String userName);

	public boolean employeeFinder(String userName);

	public boolean checkPassword(String password);

	public boolean isAdminUser(String userName, String password);

	public boolean addStudent(StudentBean s);

	public boolean addEmployee(EmployeeBean e);

	public boolean addAlumini(AluminiBean a);

	public String updateStudentDetails(String registerId);

	public String updateEmployeeDetails(String empId);

	public boolean updateAluminiDetails(String registerId);

	public boolean removeStudent(String registerId);

	public boolean removeEmployee(String empId);

	public boolean removeAlumini(String registerId);

	public List<StudentBean> viewStudentDetails();

	public List<EmployeeBean> viewEmployeeDetails();

	public boolean changePassword(String oldPassword, String newPassword, String userName);

	public boolean forgetPassword(String email, String userName);

	public boolean assignClassTeacher(String studentClass, String division, String employeeId);

	public String updateFeeStructure(double firstTerm, double secondTerm, double thirdTerm, double hostelFee,
			double busFee, double otherFee);

	public String updateCourse(String[] subjects);

	public void viewCourses(String studentClass);

	public String sendMessage(String id, String message, Date sentDate);

	public void viewMessages();

	public List<AluminiBean> viewAluminiDetails();

	public AluminiBean viewAlumini(String registerId);

	public int promoteStudents();
}
