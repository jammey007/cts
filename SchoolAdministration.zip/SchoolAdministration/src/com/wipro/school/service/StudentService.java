package com.wipro.school.service;

import java.sql.Date;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.wipro.school.DAO.StudentDao;
import com.wipro.school.bean.StudentBean;

public class StudentService implements StudentServiceInterface {

	@Override
	public String viewCourseMaterials(String studentClass, String subject) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sendMessage(String id, String message, Date sentDate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void viewMessages() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean checkStudentUser(String userName, String password) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from StudentBean");
		java.util.List<StudentBean> list = query.list();
		boolean flag = false;
		for (StudentBean sb : list) {
			if (sb.getUserName().equals(userName) && sb.getPassword().equals(password)) {
				flag = true;
				break;
			}
		}
		t.commit();
		session.close();
		return flag;
	}

	@Override
	public boolean isStudent(String registerId) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from StudentBean");
		java.util.List<StudentBean> list = query.list();
		boolean flag = false;
		for (StudentBean ab : list) {
			if (ab.getRegisterId().equals(registerId)) {
				flag = true;
				break;
			}
		}
		t.commit();
		session.close();
		return flag;
	}

	@Override
	public boolean forgetPassword(String email, String userName) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		// cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from StudentBean");
		java.util.List<StudentBean> list = query.list();
		boolean flag = false;
		for (StudentBean ab : list) {
			if (ab.getStudentEmail().equals(email) && ab.getUserName().equals(userName)) {
				flag = true;
				break;
			}
		}
		return flag;
	}

	@Override
	public boolean changePassword(String oldPassword, String newPassword, String userName) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from StudentBean");
		java.util.List<StudentBean> list = query.list();
		boolean flag = false;
		for (StudentBean sb : list) {
			if (sb.getPassword().equals(oldPassword) && sb.getUserName().equals(userName)) {
				sb.setPassword(newPassword);
				StudentDao ado = new StudentDao();
				ado.updateStudent(sb);
				flag = true;
				break;
			}
		}
		return flag;
	}

	@Override
	public String findTeacher(String registerId) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		// cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from StudentBean");
		java.util.List<StudentBean> list = query.list();
		String teacherId = null;
		for (StudentBean sb : list) {
			if (sb.getRegisterId().equals(registerId)) {
				teacherId = sb.getClassTeacher();
				break;
			}
		}
		return teacherId;
	}

}
