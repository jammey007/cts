package com.wipro.school.service;

import java.sql.Date;

public interface EmployeeServiceInterface {
	public boolean isEmployee(String empId);

	public String findDesignation(String empId);
	
	public String[] returnClassDivision(String empId);

	public boolean checkEmployeeUser(String userName, String password);

	public void viewStudentDetails(String registerId, String designation, String studentClass, String division);

	public void viewProfile();

	public String changePassword(String oldPassword, String newPassword);

	public String forgetPassword(String email);

	public String updateFeeStructure(double firstTerm, double secondTerm, double thirdTerm, double hostelFee,
			double busFee, double otherFee, String designation);

	public String updateCourse(String[] subjects, String designation, String studentClass, String division);

	public void viewCourses(String studentClass, String designation, String division);

	public String markAttendance(String designation, String studentClass, String division);

	public String updateStudentMarks(String designation, String studentClass, String division, String subjects[]);

	public String sendMessage(String id, String message, Date sentDate);

	public void viewMessages();

	public String sendMessageToParents(String regId, String message);

	public boolean forgetPassword(String email, String userName);

	public boolean changePassword(String oldPassword, String newPassword, String userName);
}
