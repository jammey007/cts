package com.wipro.school.service;

import java.sql.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.wipro.school.DAO.AdminDao;
import com.wipro.school.DAO.EmployeeDao;
import com.wipro.school.DAO.StudentDao;
import com.wipro.school.bean.AdminBean;
import com.wipro.school.bean.AluminiBean;
import com.wipro.school.bean.EmployeeBean;
import com.wipro.school.bean.StudentBean;

public class AdminService implements AdminServiceInterface {

	@Override
	public boolean addStudent(StudentBean s) {
		boolean flag = false;
		try {
			Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
			SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();
			Transaction t = session.beginTransaction();
			session.save(s);
			System.out.println("saving");
			t.commit();
			System.out.println("saved");
			session.flush();
			session.close();
			factory.close();
			flag = true;
		} catch (HibernateException e) {
			flag = false;
		}
		return flag;
	}

	public boolean addEmployee(EmployeeBean emp) {
		boolean flag = false;
		try {
			Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
			SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();
			System.out.println("opening session");
			Transaction t = session.beginTransaction();
			System.out.println(emp.getUserName());
			session.save(emp);
			t.commit();
			session.flush();
			session.close();
			factory.close();
			flag = true;
		} catch (HibernateException e) {
			flag = false;
		}
		return flag;
	}

	@Override
	public String updateStudentDetails(String registerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateEmployeeDetails(String empId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean removeStudent(String registerId) {
		boolean flag = false;
		try {
			Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
			SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();
			Query qry = session.createQuery("delete from StudentBean s where s.registerId=:id");
			qry.setParameter("id", registerId);
			qry.executeUpdate();
			Transaction t = session.beginTransaction();
			t.commit();
			session.flush();
			session.close();
			factory.close();
			flag = true;

		} catch (HibernateException e) {
			flag = false;
		}
		return flag;
	}

	@Override
	public boolean removeEmployee(String empId) {
		boolean flag = false;
		try {
			Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
			SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();
			Query qry = session.createQuery("delete from EmployeeBean emp where emp.empId=:id");
			qry.setParameter("id", empId);
			qry.executeUpdate();
			Transaction t = session.beginTransaction();
			t.commit();
			session.flush();
			session.close();
			factory.close();
			flag = true;

		} catch (HibernateException e) {
			flag = false;
		}
		return flag;
	}

	@Override
	public List<StudentBean> viewStudentDetails() {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from StudentBean");
		java.util.List<StudentBean> list = query.list();
		return list;
	}

	@Override
	public List<EmployeeBean> viewEmployeeDetails() {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from EmployeeBean");
		java.util.List<EmployeeBean> list = query.list();
		t.commit();
		session.close();
		return list;
	}

	@Override
	public boolean changePassword(String oldPassword, String newPassword, String userName) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from AdminBean");
		java.util.List<AdminBean> list = query.list();
		boolean flag = false;
		for (AdminBean ab : list) {
			if (ab.getPassword().equals(oldPassword) && ab.getUserName().equals(userName)) {
				ab.setPassword(newPassword);
				AdminDao ado = new AdminDao();
				ado.updateAdmin(ab);
				flag = true;
				break;
			}
		}
		return flag;
	}

	@Override
	public boolean forgetPassword(String email, String userName) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		// cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from AdminBean");
		java.util.List<AdminBean> list = query.list();
		boolean flag = false;
		for (AdminBean ab : list) {
			if (ab.getEmailId().equals(email) && ab.getUserName().equals(userName)) {
				flag = true;
				break;
			}
		}
		return flag;
	}

	@Override
	public boolean assignClassTeacher(String studentClass, String division, String employeeId) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		// cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from EmployeeBean");
		java.util.List<EmployeeBean> list = query.list();
		EmployeeDao edo = new EmployeeDao();
		StudentDao sdo = new StudentDao();
		boolean flag = false;
		for (EmployeeBean eb : list) {
			if (eb.getClassTeacher().equals(studentClass) && eb.getDivision().equals(division)) {
				eb.setClassTeacher("NA");
				eb.setDivision("NA");
				edo.updateEmployee(eb);
			}
		}
		Query query1 = session.createQuery("from StudentBean");
		java.util.List<StudentBean> list1 = query1.list();
		for (StudentBean sb : list1) {
			if (Integer.toString(sb.getStudentClass()).equals(studentClass) && sb.getDivision().equals(division)) {
				sb.setClassTeacher("NA");
				sdo.updateStudent(sb);
			}
		}
		for (EmployeeBean eb : list) {
			if (eb.getEmpId().equals(employeeId) && eb.getDesignation().equalsIgnoreCase("teacher")) {
				eb.setClassTeacher(studentClass);
				eb.setDivision(division);
				edo.updateEmployee(eb);

				for (StudentBean sb : list1) {
					if (sb.getStudentClass() == Integer.parseInt(studentClass) && sb.getDivision().equals(division)) {
						sb.setClassTeacher(eb.getEmployeeName());
						sdo.updateStudent(sb);
					}
				}
				flag = true;
				break;
			} else {
				flag = false;
			}
		}

		return flag;
	}

	@Override
	public String updateFeeStructure(double firstTerm, double secondTerm, double thirdTerm, double hostelFee,
			double busFee, double otherFee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateCourse(String[] subjects) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void viewCourses(String studentClass) {
		// TODO Auto-generated method stub

	}

	@Override
	public String sendMessage(String id, String message, Date sentDate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void viewMessages() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean checkPassword(String password) {

		return false;
	}

	@Override
	public boolean isAdminUser(String userName, String password) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from AdminBean");
		java.util.List<AdminBean> list = query.list();
		boolean flag = false;
		for (AdminBean ab : list) {
			if (ab.getPassword().equals(password) && ab.getUserName().equals(userName)) {
				flag = true;
				break;
			}
		}
		t.commit();
		session.close();
		return flag;
	}

	@Override
	public boolean adminFinder(String userName) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		// cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from AdminBean");
		java.util.List<AdminBean> list = query.list();
		boolean flag = false;
		for (AdminBean ab : list) {
			if (ab.getUserName().equals(userName)) {
				flag = true;
				break;
			}
		}
		t.commit();
		session.close();
		return flag;
	}

	@Override
	public int promoteStudents() {
		AdminService adServe = new AdminService();
		java.util.List<StudentBean> list = adServe.viewStudentDetails();
		int countPromotions = 0;
		int countAlumini = 0;
		for (StudentBean sb : list) {
			int studentClass = sb.getStudentClass();
			sb.setStudentClass(studentClass + 1);
			sb.setRegisterId(sb.getRegisterId());
			sb.setClassTeacher("NA");
			StudentDao sdo = new StudentDao();
			sdo.updateStudent(sb);
			countPromotions++;
		}
		for (StudentBean sb : list) {
			if (sb.getStudentClass() == 13) {
				AluminiBean aluBean = new AluminiBean();
				aluBean.setRegisterId(sb.getRegisterId());
				aluBean.setStudentName(sb.getStudentName());
				aluBean.setDateOfBirth(sb.getDateOfBirth());
				aluBean.setGender(sb.getGender());
				aluBean.setFatherName(sb.getFatherName());
				aluBean.setMotherName(sb.getMotherName());
				aluBean.setStudentEmail(sb.getStudentEmail());
				aluBean.setStudentContact(sb.getStudentContact());
				aluBean.setFatherContact(sb.getFatherContact());
				aluBean.setMotherContact(sb.getMotherContact());
				aluBean.setAddress(sb.getAddress());
				aluBean.setCity(sb.getCity());
				aluBean.setState(sb.getState());
				aluBean.setPinCode(sb.getPinCode());
				aluBean.setCaste(sb.getCaste());
				aluBean.setReligion(sb.getReligion());
				aluBean.setNationality(sb.getNationality());
				aluBean.setPassedOut(java.time.LocalDateTime.now().getYear());
				adServe.addAlumini(aluBean);
				adServe.removeStudent(aluBean.getRegisterId());
				countAlumini++;
			}
		}
		return countPromotions - countAlumini;
	}

	@Override
	public boolean addAlumini(AluminiBean a) {
		boolean flag = false;
		try {
			Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
			SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();
			Transaction t = session.beginTransaction();
			session.save(a);
			t.commit();
			session.flush();
			session.close();
			factory.close();
			flag = true;
		} catch (HibernateException e) {
			flag = false;
		}
		return flag;
	}

	@Override
	public boolean updateAluminiDetails(String registerId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean removeAlumini(String registerId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<AluminiBean> viewAluminiDetails() {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from AluminiBean");
		java.util.List<AluminiBean> list = query.list();
		return list;
	}

	@Override
	public AluminiBean viewAlumini(String registerId) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from AluminiBean");
		java.util.List<AluminiBean> list = query.list();
		AluminiBean alBean = null;
		for (AluminiBean ab : list) {
			if (ab.getRegisterId().equals(registerId)) {
				alBean = ab;
				break;
			}
		}
		return alBean;
	}

	@Override
	public boolean studentFinder(String userName) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		// cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from StudentBean");
		java.util.List<StudentBean> list = query.list();
		boolean flag = false;
		for (StudentBean ab : list) {
			if (ab.getUserName().equals(userName)) {
				flag = true;
				break;
			}
		}
		t.commit();
		session.close();
		return flag;
	}

	@Override
	public boolean employeeFinder(String userName) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		// cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from EmployeeBean");
		java.util.List<EmployeeBean> list = query.list();
		boolean flag = false;
		for (EmployeeBean ab : list) {
			if (ab.getUserName().equals(userName)) {
				flag = true;
				break;
			}
		}
		t.commit();
		session.close();
		return flag;
	}

}
