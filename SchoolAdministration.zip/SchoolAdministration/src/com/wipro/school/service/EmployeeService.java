package com.wipro.school.service;

import java.sql.Date;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.wipro.school.DAO.EmployeeDao;
import com.wipro.school.bean.EmployeeBean;

public class EmployeeService implements EmployeeServiceInterface {

	@Override
	public void viewStudentDetails(String registerId, String designation, String studentClass, String division) {
		// TODO Auto-generated method stub

	}

	@Override
	public void viewProfile() {
		// TODO Auto-generated method stub

	}

	@Override
	public String changePassword(String oldPassword, String newPassword) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String forgetPassword(String email) {

		return null;
	}

	@Override
	public String updateFeeStructure(double firstTerm, double secondTerm, double thirdTerm, double hostelFee,
			double busFee, double otherFee, String designation) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateCourse(String[] subjects, String designation, String studentClass, String division) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void viewCourses(String studentClass, String designation, String division) {
		// TODO Auto-generated method stub

	}

	@Override
	public String markAttendance(String designation, String studentClass, String division) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateStudentMarks(String designation, String studentClass, String division, String[] subjects) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sendMessage(String id, String message, Date sentDate) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void viewMessages() {
		// TODO Auto-generated method stub

	}

	@Override
	public String sendMessageToParents(String regId, String message) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean checkEmployeeUser(String userName, String password) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from EmployeeBean");
		java.util.List<EmployeeBean> list = query.list();
		boolean flag = false;
		for (EmployeeBean ab : list) {
			if (ab.getUserName().equals(userName) && ab.getPassword().equals(password)) {
				flag = true;
				break;
			}
		}
		t.commit();
		session.close();
		return flag;
	}

	@Override
	public boolean isEmployee(String empId) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from EmployeeBean");
		java.util.List<EmployeeBean> list = query.list();
		boolean flag = false;
		for (EmployeeBean eb : list) {
			if (eb.getEmpId().equals(empId)) {
				flag = true;
				break;
			}
		}
		t.commit();
		session.close();
		return flag;
	}

	@Override
	public boolean forgetPassword(String email, String userName) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		// cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from EmployeeBean");
		java.util.List<EmployeeBean> list = query.list();
		boolean flag = false;
		for (EmployeeBean ab : list) {
			if (ab.getEmailId().equals(email) && ab.getUserName().equals(userName)) {
				flag = true;
				break;
			}
		}
		return flag;
	}

	@Override
	public boolean changePassword(String oldPassword, String newPassword, String userName) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from EmployeeBean");
		java.util.List<EmployeeBean> list = query.list();
		boolean flag = false;
		for (EmployeeBean eb : list) {
			if (eb.getPassword().equals(oldPassword) && eb.getUserName().equals(userName)) {
				eb.setPassword(newPassword);
				EmployeeDao edo = new EmployeeDao();
				edo.updateEmployee(eb);
				flag = true;
				break;
			}
		}
		return flag;
	}

	@Override
	public String findDesignation(String empId) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from EmployeeBean");
		java.util.List<EmployeeBean> list = query.list();
		String designation = "";
		for (EmployeeBean eb : list) {
			if (eb.getEmpId().equals(empId)) {
				designation = eb.getDesignation();
			}
		}
		return designation;
	}

	@Override
	public String[] returnClassDivision(String empId) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from EmployeeBean");
		java.util.List<EmployeeBean> list = query.list();
		String classDiv[] = new String[2];
		for (EmployeeBean eb : list) {
			if (eb.getEmpId().equals(empId)) {
				classDiv[0] = eb.getClassTeacher();
				classDiv[1] = eb.getDivision();
			}
		}
		return classDiv;
	}

}
