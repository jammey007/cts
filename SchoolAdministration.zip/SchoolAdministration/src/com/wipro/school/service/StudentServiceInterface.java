package com.wipro.school.service;

import java.sql.Date;

public interface StudentServiceInterface {
	public boolean isStudent(String registerId);

	public boolean checkStudentUser(String userName, String password);

	public String viewCourseMaterials(String studentClass, String subject);

	public String sendMessage(String id, String message, Date sentDate);

	public void viewMessages();

	public boolean forgetPassword(String email, String userName);

	public boolean changePassword(String oldPassword, String newPassword, String userName);

	public String findTeacher(String registerId);
}
