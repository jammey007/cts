package com.wipro.school.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.wipro.school.service.AdminService;

@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("option");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		if (action.equals("add student")) {
			response.sendRedirect("uploadStudent.jsp");
		} else if (action.equals("delete student")) {
			response.sendRedirect("DeleteUser.jsp");
		} else if (action.equals("view student")) {
			response.sendRedirect("GetViewUser.jsp");
		} else if (action.equals("add employee")) {
			response.sendRedirect("UploadEmployee.jsp");
		} else if (action.equals("delete employee")) {
			response.sendRedirect("DeleteUser.jsp");
		} else if (action.equals("view employee")) {
			response.sendRedirect("GetViewUser.jsp");
		} else if (action.equals("promote students")) {
			AdminService adServe = new AdminService();
			String result = Integer.toString(adServe.promoteStudents());
			request.setAttribute("message", result);
			request.getRequestDispatcher("promote.jsp").forward(request, response);
		} else if (action.equals("change password")) {
			response.sendRedirect("changePassword.jsp");
		} else if (action.equals("update class teacher")) {
			response.sendRedirect("updateTeacher.jsp");
		} else if (action.equals("upload timetable")) {
			response.sendRedirect("uploadTimetable.jsp");
		} else if (action.equals("view timetable")) {
			response.sendRedirect("viewTimetable.jsp");
		} else if (action.equals("view alumini")) {
			response.sendRedirect("viewAlumini.jsp");
		}  else if (action.equals("logout")) {
			HttpSession s =request.getSession();
			s.invalidate();
			response.sendRedirect("HomeUI.jsp");
		} else if (action.equals("update feestructure")) {
			response.sendRedirect("updateFees.jsp");
		}else if (action.equals("clear all")) {
			Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
			SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();
			Transaction t = session.beginTransaction();
			Query qry = session.createSQLQuery("truncate table employee");
			qry.executeUpdate();
			qry = session.createSQLQuery("truncate table students");
			qry.executeUpdate();
			qry=session.createSQLQuery("truncate table alumini");
			qry.executeUpdate();
			t.commit();
			session.flush();
			session.close();
			factory.close();
			response.sendRedirect("DeleteAll.jsp");
		}
	}
}
