package com.wipro.school.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/HomeUIServlet")
public class HomeUIServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("doer");
		System.out.println(action);
		if (action.equalsIgnoreCase("Login Portal")) {
			String page = "";
			try {

			} catch (Exception e) {
				page = "error.jsp";
			} finally {
				page = "portals.jsp";
			}
			RequestDispatcher dd = request.getRequestDispatcher(page);
			dd.forward(request, response);
		} else if (action.equals("Home")) {
			response.sendRedirect("HomeUI.jsp");
		} else if (action.equals("About Us")) {
			response.sendRedirect("AboutUs.jsp");
		} else if (action.equals("Academics")) {
			response.sendRedirect("Academics.jsp");
		}else if(action.equals("Achievements")) {
			response.sendRedirect("Achievements.jsp");
		}else if(action.equals("Facilities")) {
			response.sendRedirect("Facilities.jsp");
		}
	}
}
