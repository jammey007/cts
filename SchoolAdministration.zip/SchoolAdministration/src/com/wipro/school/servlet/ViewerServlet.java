package com.wipro.school.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.school.DAO.EmployeeDao;
import com.wipro.school.DAO.StudentDao;
import com.wipro.school.bean.EmployeeBean;
import com.wipro.school.bean.StudentBean;
import com.wipro.school.service.AdminService;
import com.wipro.school.service.EmployeeService;
import com.wipro.school.service.StudentService;

/**
 * Servlet implementation class ViewerServlet
 */
@WebServlet("/ViewerServlet")
public class ViewerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		String userId = request.getParameter("userid");
		if (action.equals("search")) {
			AdminService aServ = new AdminService();
			StudentService sServ = new StudentService();
			EmployeeService eServ = new EmployeeService();
			if (sServ.isStudent(userId)) {
				StudentDao sdo = new StudentDao();
				request.setAttribute("message", sdo.searchStudent(userId));
				request.getRequestDispatcher("ViewStudentDetails.jsp").forward(request, response);
			} else if (eServ.isEmployee(userId)) {
				EmployeeDao edo = new EmployeeDao();
				request.setAttribute("message", edo.searchEmployee(userId));
				request.getRequestDispatcher("ViewEmployeeDetails.jsp").forward(request, response);
			}else {
				response.sendRedirect("viewError.jsp");
			}

		}
	}

}
