package com.wipro.school.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.school.DAO.AdminDao;
import com.wipro.school.DAO.EmployeeDao;
import com.wipro.school.DAO.StudentDao;
import com.wipro.school.bean.AdminBean;
import com.wipro.school.bean.EmployeeBean;
import com.wipro.school.bean.StudentBean;
import com.wipro.school.service.AdminService;
import com.wipro.school.service.EmployeeService;
import com.wipro.school.service.StudentService;

@WebServlet("/ForgetUserServlet")
public class ForgetUserServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userName = request.getParameter("user");
		String email = request.getParameter("emailid");
		String newPassword = request.getParameter("newpass");
		String confirmPassword = request.getParameter("confirmpass");
		AdminService as = new AdminService();
		StudentService stuService= new StudentService();
		EmployeeService empService=new EmployeeService();
		if (newPassword.equals(confirmPassword)) {
			if (as.adminFinder(userName)) {
				if (as.forgetPassword(email, userName)) {
					AdminDao ado = new AdminDao();
					AdminBean ab = new AdminBean();
					ab.setUserName(userName);
					ab.setPassword(newPassword);
					ab.setEmailId(email);
					ado.updateAdmin(ab);
					response.sendRedirect("passChanged.jsp");
				}else {
					response.sendRedirect("ErrorForget.jsp");
				}
			}else if(stuService.isStudent(userName)) {
				if(stuService.forgetPassword(email, userName)) {
					StudentDao sdo= new StudentDao();
					StudentBean sb=sdo.searchStudent(userName);
					sb.setPassword(newPassword);
					sdo.updateStudent(sb);
					response.sendRedirect("passChanged.jsp");
				}else {
					response.sendRedirect("ErrorForget.jsp");
				}
			}else if(empService.isEmployee(userName)) {
				EmployeeDao edo= new EmployeeDao();
				EmployeeBean eb=edo.searchEmployee(userName);
				eb.setPassword(newPassword);
				edo.updateEmployee(eb);
				response.sendRedirect("passChanged.jsp");
			}
		}else {
			response.sendRedirect("passwordWrong.jsp");
		}
	}
}
