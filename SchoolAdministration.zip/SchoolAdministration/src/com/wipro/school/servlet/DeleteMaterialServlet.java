package com.wipro.school.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.wipro.school.bean.MaterialBean;
import com.wipro.school.service.AdminService;

@WebServlet("/DeleteMaterialServlet")
public class DeleteMaterialServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String classDivision = request.getParameter("classdiv");
		String action = request.getParameter("action");
		AdminService adServe = new AdminService();
		String user = (String) request.getSession().getAttribute("userName");
		if (action.equals("delete")) {
			Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
			SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();
			Transaction tx = session.beginTransaction();
			Query qry = session.createQuery("from MaterialBean");
			List<MaterialBean> list = qry.list();
			String message = "not found";
			for (MaterialBean mb : list) {
				if (mb.getClassAndDivision().equals(classDivision)) {
					session.delete(mb);
					message = "deleted";
				}
			}
			tx.commit();
			session.close();
			if (classDivision.equals("select")) {
				message = "not found";
			}
			request.setAttribute("message", message);
			request.getRequestDispatcher("deleteFile.jsp").forward(request, response);
		} else if (action.equals("home") && adServe.employeeFinder(user)) {
			response.sendRedirect("EmployeeHome.jsp");
		} else if (action.equals("home") && adServe.studentFinder(user)) {
			response.sendRedirect("StudentHome.jsp");
		}
	}

}
