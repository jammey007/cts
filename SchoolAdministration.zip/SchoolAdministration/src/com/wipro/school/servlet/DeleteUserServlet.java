package com.wipro.school.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.school.service.AdminService;
import com.wipro.school.service.EmployeeService;
import com.wipro.school.service.StudentService;

@WebServlet("/DeleteUserServlet")
public class DeleteUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		String userId = request.getParameter("userid");
		String message = "notfound";
		if (action.equals("delete")) {
			StudentService stuSer = new StudentService();
			EmployeeService empSer = new EmployeeService();
			AdminService adSer = new AdminService();
			if (stuSer.isStudent(userId)) {
				if (adSer.removeStudent(userId)) {
					message = "removed";
				}
			} else if (empSer.isEmployee(userId)) {
				if (adSer.removeEmployee(userId)) {
					message = "removed";
				}
			}
			request.setAttribute("message", message);
			request.getRequestDispatcher("DeleteResult.jsp").forward(request, response);
		}

	}

}
