package com.wipro.school.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.wipro.school.DAO.FeesDao;
import com.wipro.school.bean.FeesTypeBean;

@WebServlet("/UpdateFeesServlet")
public class UpdateFeesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String studentClass = request.getParameter("stuclass").toUpperCase();
		String feesType = request.getParameter("select");
		System.out.println(studentClass);
		System.out.println(feesType);
		String amount = request.getParameter("amount");
		String message = "";
		FeesTypeBean fees = new FeesTypeBean();
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Query qry = session.createQuery("from FeesTypeBean");
		List<FeesTypeBean> list = qry.list();
		FeesDao fee = new FeesDao();
		FeesTypeBean feeType = new FeesTypeBean();
		if (list.isEmpty()) {
			String stuClass[] = { "PREKG", "LKG", "UKG", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11",
					"12" };
			for (int i = 0; i < stuClass.length; i++) {
				String studentDivClass = stuClass[i];
				feeType.setStudentClass(studentDivClass);
				feeType.setFirstTerm(0);
				feeType.setSecondTerm(0);
				feeType.setThirdTerm(0);
				feeType.setBusFees(0);
				feeType.setHostelFees(0);
				fee.updateFees(feeType);
			}
		}
		if (feesType.equals("select")||studentClass.equals("selectclass")) {
			message = "need to select the field";
		} else {
			for (FeesTypeBean ftb : list) {
				if (ftb.getStudentClass().equals(studentClass)) {
					if (feesType.equals("firstterm")) {
						ftb.setFirstTerm(Double.parseDouble(amount));
					} else if (feesType.equals("secondterm")) {
						ftb.setSecondTerm(Double.parseDouble(amount));
					} else if (feesType.equals("thirdterm")) {
						ftb.setThirdTerm(Double.parseDouble(amount));
					} else if (feesType.equals("hostel")) {
						ftb.setHostelFees(Double.parseDouble(amount));
					} else if (feesType.equals("bus")) {
						ftb.setBusFees(Double.parseDouble(amount));
					}
					fee.updateFees(ftb);
					message = "updated";
					break;
				}
			}
		}
		request.setAttribute("message", message);
		request.getRequestDispatcher("feeUpdateResult.jsp").forward(request, response);
	}
}
