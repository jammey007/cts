package com.wipro.school.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.school.service.AdminService;
import com.wipro.school.service.EmployeeService;
import com.wipro.school.service.StudentService;

@WebServlet("/AdminLogInServlet")
public class AdminLogInServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userName = request.getParameter("username");
		String password = request.getParameter("password");
		String action = request.getParameter("action");
		System.out.println(action);
		response.setContentType("text/html");
		if (action.equals("submit")) {
			AdminService adminService = new AdminService();
			StudentService stuService = new StudentService();
			EmployeeService empService = new EmployeeService();
			if (adminService.isAdminUser(userName, password)) {
				HttpSession s = request.getSession();
				s.setAttribute("userName", userName);
				response.sendRedirect("AdminHome.jsp");
			} else if (stuService.checkStudentUser(userName, password)) {
				HttpSession s = request.getSession();
				s.setAttribute("userName", userName);
				response.sendRedirect("StudentHome.jsp");
			} else if (empService.checkEmployeeUser(userName, password)) {
				HttpSession s = request.getSession();
				s.setAttribute("userName", userName);
				response.sendRedirect("EmployeeHome.jsp");
			} else {
				response.sendRedirect("ErrorSignup.jsp");
			}
		} else if (action.equals("forgetpassword")) {
			response.sendRedirect("ForgetPassword.jsp");
		}
	}
}