package com.wipro.school.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.wipro.school.DAO.EmployeeDao;
import com.wipro.school.DAO.StudentDao;
import com.wipro.school.bean.EmployeeBean;
import com.wipro.school.bean.StudentBean;
import com.wipro.school.service.StudentService;

@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("option");
		StudentDao sdo = new StudentDao();
		EmployeeDao edo = new EmployeeDao();
		StudentService stuServe = new StudentService();
		HttpSession s = request.getSession();
		String user = (String) s.getAttribute("userName");
		if (action.equals("view profile")) {
			request.setAttribute("message", sdo.searchStudent(user));
			request.getRequestDispatcher("ViewStudentDetails.jsp").forward(request, response);
		} else if (action.equals("view class teacher")) {
			System.out.println(user);
			String teacherId = stuServe.findTeacher(user);
			System.out.println(teacherId);
			if (teacherId == null) {
				request.setAttribute("message", "not found");
				request.getRequestDispatcher("notFound.jsp").forward(request, response);
			} else {
				Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
				SessionFactory factory = cfg.buildSessionFactory();
				Session session = factory.openSession();
				Query qry = session.createQuery("from EmployeeBean");
				List<EmployeeBean> list = qry.list();
				String empId = null;
				for (EmployeeBean eb : list) {
					if (teacherId.equals(eb.getEmployeeName())) {
						empId = eb.getEmpId();
						break;
					}
				}
				System.out.println(empId);
				request.setAttribute("message", edo.searchEmployee(empId));
				request.getRequestDispatcher("ViewEmployeeDetails.jsp").forward(request, response);
			}
		} else if (action.equals("view time table")) {
			StudentBean sb = sdo.searchStudent(user);
			request.setAttribute("stuclass", sb.getStudentClass());
			request.setAttribute("div", sb.getDivision());
			request.getRequestDispatcher("viewTimetable.jsp").forward(request, response);
		} else if (action.equals("view materials")) {
			response.sendRedirect("viewMaterials.jsp");
		} else if (action.equals("change password")) {
			response.sendRedirect("changePassword.jsp");
		} else if (action.equals("logout")) {
			s.invalidate();
			response.sendRedirect("HomeUI.jsp");
		}
	}

}
