package com.wipro.school.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.school.service.AdminService;
import com.wipro.school.service.EmployeeService;
import com.wipro.school.service.StudentService;

@WebServlet("/ChangePassword")
public class ChangePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userName = request.getParameter("user");
		String oldPassword = request.getParameter("oldpass");
		String newPassword = request.getParameter("newpass");
		String confirmPassword = request.getParameter("confirmpass");
		String action = request.getParameter("action");
		String message = "";
		String user="";
		if (action.equals("changepassword")) {
			System.out.println(userName+" "+oldPassword+" "+newPassword+" "+confirmPassword);
			AdminService adServe = new AdminService();
			StudentService stServe = new StudentService();
			EmployeeService empServe = new EmployeeService();
			if (adServe.isAdminUser(userName, oldPassword)) {
				System.out.println(1);
				if (newPassword.equals(confirmPassword)) {
					System.out.println(2);
					if (adServe.changePassword(oldPassword, newPassword, userName)) {
						message = "Password changed";
						user="admin";
						System.out.println(message+" "+user);
					} else {
						message = "Error occured";
					}
				} else {
					message = "Password mismatch";
				}
			} else if (stServe.checkStudentUser(userName, oldPassword)) {
				if (newPassword.equals(confirmPassword)) {
					if (stServe.changePassword(oldPassword, newPassword, userName)) {
						message = "Password changed.";
						user="student";
					} else {
						message = "Error occured";
					}
				} else {
					message = "Password mismatch";
				}
			} else if (empServe.checkEmployeeUser(userName, oldPassword)) {
				if (newPassword.equals(confirmPassword)) {
					if (empServe.changePassword(oldPassword, newPassword, userName)) {
						message = "Password changed";
						user="employee";
					} else {
						message = "Error occured";
					}
				} else {
					message = "Password mismatch";
				}
			} else {
				message = "UserName or password is wrong";
			}
		}
		request.setAttribute("message", message);
		request.setAttribute("user", user);
		request.getRequestDispatcher("ErrorChangePassword.jsp").forward(request, response);
	}

}
