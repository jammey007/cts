package com.wipro.school.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.wipro.school.bean.MaterialBean;

@WebServlet("/UploadMaterials")
public class UploadMaterials extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private final String UPLOAD_DIRECTORY = "C:/StudentMaterials/";

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String message = "";
		String studentClass = "";
		String division = "";
		String subject = "";
		File theDir = new File(UPLOAD_DIRECTORY);
		if (!theDir.exists()) {
			System.out.println("creating directory: " + theDir.getName());
			boolean result = false;
			try {
				theDir.mkdir();
				result = true;
			} catch (SecurityException se) {

			}
			if (result) {
				System.out.println("DIR created");
			}
		}
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		if (isMultipart) {
			FileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);
			try {
				List<FileItem> multiparts = upload.parseRequest(request);
				Iterator<FileItem> iter = multiparts.iterator();
				while (iter.hasNext()) {
					FileItem item = iter.next();
					InputStream input = item.getInputStream();
					if (item.getFieldName().equals("stuclass")) {
						byte[] str = new byte[input.available()];
						input.read(str);
						studentClass = new String(str, "UTF8");
					}
					if (item.getFieldName().equals("division")) {
						byte[] str = new byte[input.available()];
						input.read(str);
						division = new String(str, "UTF8");
					}
					if (item.getFieldName().equals("subject")) {
						byte[] str = new byte[input.available()];
						input.read(str);
						subject = new String(str, "UTF8");
					}
				}
				for (FileItem item : multiparts) {
					if (!item.isFormField()) {
						String name = new File(item.getName()).getName();
						item.write(new File(UPLOAD_DIRECTORY + File.separator + name));
						String fileName = UPLOAD_DIRECTORY + name;
						Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
						SessionFactory fctry = cfg.buildSessionFactory();
						Session session = fctry.openSession();
						Transaction tx = session.beginTransaction();
						File file = new File(fileName);
						byte[] pdfInBytes = new byte[(int) file.length()];
						FileInputStream inputStream = new FileInputStream(file);
						inputStream.read(pdfInBytes);
						inputStream.close();
						MaterialBean ttb = new MaterialBean();
						ttb.setClassAndDivision(studentClass + "-" + division+"-"+subject);
						ttb.setPdfFile(pdfInBytes);
						ttb.setSubject(subject);
						session.save(ttb);
						System.out.println("saving");
						tx.commit();
						System.out.println("saved");
						message = "uploaded";
						session.close();
					}
				}
			} catch (Exception e) {
				message = "File Upload Failed due to " + e;
				e.printStackTrace();
			}
		} else {
			message = "This Servlet only handles file upload request";
		}
		request.setAttribute("message", message);
		request.getRequestDispatcher("/materialUploadResult.jsp").forward(request, response);
	}
}
