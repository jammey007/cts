package com.wipro.school.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.school.service.AdminService;

@WebServlet("/ReturnServlet")
public class ReturnServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession s = request.getSession();
		AdminService adSrve = new AdminService();
		String user = (String) s.getAttribute("userName");
		System.out.println(user);
		if (request.getParameter("action").equals("go home")) {
			if (adSrve.adminFinder(user)) {
				response.sendRedirect("AdminHome.jsp");
			} else if (adSrve.employeeFinder(user)) {
				response.sendRedirect("EmployeeHome.jsp");
			} else if (adSrve.studentFinder(user)) {
				response.sendRedirect("StudentHome.jsp");
			}else {
				response.sendRedirect("HomeUI.jsp");
			}
		}
	}
}
