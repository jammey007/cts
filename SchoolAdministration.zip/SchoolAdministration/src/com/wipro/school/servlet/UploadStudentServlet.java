package com.wipro.school.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.wipro.school.bean.StudentBean;
import com.wipro.school.service.AdminService;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

@WebServlet("/UploadStudentServlet")
public class UploadStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final String UPLOAD_DIRECTORY = "C:/StudentDetails/";

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		File theDir = new File(UPLOAD_DIRECTORY);
		if (!theDir.exists()) {
		    System.out.println("creating directory: " + theDir.getName());
		    boolean result = false;

		    try{
		        theDir.mkdir();
		        result = true;
		    } 
		    catch(SecurityException se){
		        //handle it
		    }        
		    if(result) {    
		        System.out.println("DIR created");  
		    }
		}
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		String message = "";
		if (isMultipart) {
			FileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);
			try {
				List<FileItem> multiparts = upload.parseRequest(request);
				for (FileItem item : multiparts) {
					if (!item.isFormField()) {
						String name = new File(item.getName()).getName();
						item.write(new File(UPLOAD_DIRECTORY + File.separator + name));
						String fileName = UPLOAD_DIRECTORY + name;
						try {
							if (fileName.substring(fileName.length()-3, fileName.length()).equals("xls")) {
								Workbook wb = Workbook.getWorkbook(new FileInputStream(fileName));
								Sheet sh = wb.getSheet(0);
								for (int i = 1; i < sh.getRows(); i++) {
									StudentBean stuBean = new StudentBean();
									String stuClass=sh.getCell(5, i).getContents();
									if(stuClass.equalsIgnoreCase("PREKG")) {
										stuClass="-2";
									}else if(stuClass.equalsIgnoreCase("LKG")) {
										stuClass="-1";
									}else if(stuClass.equalsIgnoreCase("UKG")) {
										stuClass="0";
									}
									stuBean.setStudentName(sh.getCell(0, i).getContents());
									stuBean.setRegisterId(sh.getCell(1, i).getContents());
									stuBean.setUserName(sh.getCell(2, i).getContents());
									stuBean.setPassword(sh.getCell(3, i).getContents());
									stuBean.setDateOfBirth(generateDate(sh.getCell(4, i).getContents()));
									stuBean.setStudentClass(Integer.parseInt(stuClass));
									stuBean.setDivision(sh.getCell(6, i).getContents());
									stuBean.setFatherName(sh.getCell(7, i).getContents());
									stuBean.setMotherName(sh.getCell(8, i).getContents());
									stuBean.setAddress(sh.getCell(9, i).getContents());
									stuBean.setCity(sh.getCell(10, i).getContents());
									stuBean.setState(sh.getCell(11, i).getContents());
									stuBean.setPinCode(Integer.parseInt(sh.getCell(12, i).getContents()));
									stuBean.setStudentEmail(sh.getCell(13, i).getContents());
									stuBean.setStudentContact(Long.parseLong(sh.getCell(14, i).getContents()));
									stuBean.setFatherContact(Long.parseLong(sh.getCell(15, i).getContents()));
									stuBean.setMotherContact(Long.parseLong(sh.getCell(16, i).getContents()));
									stuBean.setGender(sh.getCell(17, i).getContents());
									stuBean.setCaste(sh.getCell(18, i).getContents());
									stuBean.setReligion(sh.getCell(19, i).getContents());
									stuBean.setNationality(sh.getCell(20, i).getContents());
									stuBean.setClassTeacher(sh.getCell(21, i).getContents());
									stuBean.setAmountPaid(Integer.parseInt(sh.getCell(22, i).getContents()));
									stuBean.setAccomodation(sh.getCell(23, i).getContents());
									stuBean.setDistance(Integer.parseInt(sh.getCell(24, i).getContents()));
									AdminService service = new AdminService();
									if(service.addStudent(stuBean)) {
									message = "uploaded";
									}else {
										message="problem uploading";
									}
								}
							}else {
								message="undefined file type";
							}
						} catch (BiffException e) {
							e.printStackTrace();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}

				

			} catch (Exception e) {
				message = "File Upload Failed due to " + e;
			}
		} else {
			message = "This Servlet only handles file upload request";
		}
		request.setAttribute("message", message);
		request.getRequestDispatcher("/result.jsp").forward(request, response);
	}

	public static Date generateDate(String input) {
		String startDate = input.replaceAll("/", "-");
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
		java.util.Date date = null;
		Date sqlStartDate = null;
		try {
			date = sdf1.parse(startDate);
			sqlStartDate = new java.sql.Date(date.getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return sqlStartDate;
	}
}
