package com.wipro.school.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wipro.school.bean.EmployeeBean;
import com.wipro.school.service.AdminService;
import com.wipro.school.service.EmployeeService;

@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("here comes the viper.....");
		String action = request.getParameter("option");
		EmployeeService empServe = new EmployeeService();
		AdminService adServe = new AdminService();

		HttpSession s = request.getSession();
		String user = (String) s.getAttribute("userName");
		System.out.println(user);
		System.out.println(action);
		if (action.equals("view student")) {
			String message = "";
			if (empServe.isEmployee(user)) {
				if (empServe.findDesignation(user).equalsIgnoreCase("teacher")) {
					message = "teacher";
				} else {
					message = "User may not be a teacher";
				}
			} else {
				message = "User not found";
			}
			request.setAttribute("message", message);
			request.getRequestDispatcher("viewStudentList.jsp").forward(request, response);
		} else if (action.equals("view profile")) {
			List<EmployeeBean> list = adServe.viewEmployeeDetails();
			EmployeeBean emp = null;
			for (EmployeeBean eb : list) {
				if (eb.getEmpId().equals(user)) {
					emp = eb;
					break;
				}
			}
			request.setAttribute("message", emp);
			request.getRequestDispatcher("viewEmployeeProfile.jsp").forward(request, response);
		} else if (action.equals("change password")) {
			response.sendRedirect("changePassword.jsp");
		}else if (action.equals("view time table")) {
			response.sendRedirect("viewTimetable.jsp");
		}else if (action.equals("upload materials")) {
			response.sendRedirect("uploadMaterials.jsp");
		}else if (action.equals("view materials")) {
			response.sendRedirect("viewMaterials.jsp");
		} else if (action.equals("delete materials")) {
			response.sendRedirect("deleteMaterial.jsp");
		} else if (action.equals("logout")) {
			s.invalidate();
			response.sendRedirect("HomeUI.jsp");
		}

	}

}
