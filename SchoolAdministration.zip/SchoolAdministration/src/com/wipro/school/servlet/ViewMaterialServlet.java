package com.wipro.school.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.wipro.school.bean.MaterialBean;
import com.wipro.school.service.AdminService;

@WebServlet("/ViewMaterialServlet")
public class ViewMaterialServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String studentClass = request.getParameter("classdiv");
		String action = request.getParameter("action");
		String message = "nothing to view";
		if(studentClass.equals("select")) {
			message="no files to view";
		}
		AdminService adServe = new AdminService();
		String user = (String) request.getSession().getAttribute("userName");
		if (action.equals("view")) {
			boolean flag = false;
			try {
				Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
				SessionFactory factory = cfg.buildSessionFactory();
				Session session = factory.openSession();
				Query qry = session.createQuery("from MaterialBean");
				List<MaterialBean> list = qry.list();
				for (MaterialBean ttb : list) {
					if (ttb.getClassAndDivision().equals(studentClass)) {
						byte[] pdfFile = ttb.getPdfFile();
						String fileName = "C:/StudentMaterials/" + studentClass+ ".pdf";
						File file = new File(fileName);
						FileOutputStream outStream = new FileOutputStream(file);
						outStream.write(pdfFile);
						outStream.close();
						File downloadFile = new File(fileName);
						FileInputStream inStream = new FileInputStream(downloadFile);
						String relativePath = getServletContext().getRealPath("");
						System.out.println("relativePath = " + relativePath);
						ServletContext context = getServletContext();
						String mimeType = context.getMimeType(fileName);
						if (mimeType == null) {
							mimeType = "application/pdf";
						}
						System.out.println("MIME type: " + mimeType);
						response.setContentType(mimeType);
						response.setContentLength((int) downloadFile.length());
						String headerKey = "Content-Disposition";
						String headerValue = String.format("inline; filename=\"%s\"", downloadFile.getName());
						response.setHeader(headerKey, headerValue);
						OutputStream oStream = response.getOutputStream();

						byte[] buffer = new byte[4096];
						int bytesRead = -1;

						while ((bytesRead = inStream.read(buffer)) != -1) {
							oStream.write(buffer, 0, bytesRead);
						}

						inStream.close();
						oStream.close();
						System.out.println(new File(fileName).delete());
						flag = true;
						break;
					}
				}
				session.close();
			} catch (Exception e) {
				flag = false;
				e.printStackTrace();
			}
			if (flag) {
				request.setAttribute("message", "downloaded");
				request.getRequestDispatcher("viewMaterialResult.jsp").forward(request, response);
			} else {
				request.setAttribute("message", "download failed");
				request.getRequestDispatcher("viewMaterialResult.jsp").forward(request, response);
			}
		} else if (action.equals("home") && adServe.employeeFinder(user)) {
			response.sendRedirect("EmployeeHome.jsp");
		} else if (action.equals("home") && adServe.studentFinder(user)) {
			response.sendRedirect("StudentHome.jsp");
		}
	}

}
