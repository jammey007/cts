package com.wipro.school.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.school.service.AdminService;

@WebServlet("/AssignClassTeacher")
public class AssignClassTeacher extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String employeeId = request.getParameter("empid");
		String studentClass = request.getParameter("class");
		if(studentClass.equals("PREKG")) {
			studentClass="-2";
		}else if(studentClass.equals("LKG")) {
			studentClass="-1";
		}else if(studentClass.equals("UKG")) {
			studentClass="0";
		}
		String division = request.getParameter("division");
		String action = request.getParameter("action");
		String message = "";
		if (action.equals("assign")) {
			AdminService adServe = new AdminService();
			if (adServe.assignClassTeacher(studentClass, division, employeeId)) {
				message = "assigned";
			} else {
				message = "notassigned";
			}
		}
		request.setAttribute("message", message);
		request.getRequestDispatcher("AssignResult.jsp").forward(request, response);
	}

}
