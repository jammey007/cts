package com.wipro.school.DAO;

import java.util.ArrayList;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.wipro.school.bean.AdminBean;

public class AdminDao implements AdminInterface {
	public boolean updateAdmin(AdminBean ab) {
		boolean flag = false;
		try {
			Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
			// cfg.configure("hibernate.cfg.xml");
			SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();
			Transaction t = session.beginTransaction();
			session.update(ab);
			t.commit();
			session.close();
			factory.close();
			flag = true;
		} catch (HibernateException e) {
			flag = false;
		}
		return flag;
	}

	@Override
	public ArrayList<AdminBean> showAdmin() {

		return null;
	}
}
