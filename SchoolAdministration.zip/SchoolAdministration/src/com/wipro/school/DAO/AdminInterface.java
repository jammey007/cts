package com.wipro.school.DAO;
import java.util.ArrayList;

import com.wipro.school.bean.AdminBean;

public interface AdminInterface 
{
   public boolean updateAdmin(AdminBean ab);
   public ArrayList<AdminBean> showAdmin();
}
