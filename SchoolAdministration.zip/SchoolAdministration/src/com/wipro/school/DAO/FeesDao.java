package com.wipro.school.DAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.wipro.school.bean.FeesTypeBean;

public class FeesDao implements FeesInterface {

	@Override
	public boolean updateFees(FeesTypeBean ftb) {
		boolean flag = false;
		try {
			Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
			SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();
			Transaction t = session.beginTransaction();
			session.saveOrUpdate(ftb);
			t.commit();
			session.close();
			flag = true;
		} catch (Exception e) {
			flag = false;
		}
		return flag;
	}
}
