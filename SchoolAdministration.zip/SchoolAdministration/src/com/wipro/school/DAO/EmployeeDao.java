package com.wipro.school.DAO;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.wipro.school.bean.EmployeeBean;
import com.wipro.school.bean.StudentBean;

public class EmployeeDao implements EmployeeInterface {

	@Override
	public boolean updateEmployee(EmployeeBean eb) {
		boolean flag = false;
		try {
			Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
			SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();
			Transaction t = session.beginTransaction();
			session.update(eb);
			t.commit();
			session.close();
			factory.close();
			flag = true;
		} catch (HibernateException e) {
			flag = false;
		}
		return flag;
	}

	@Override
	public void viewEmployee(String empId) {
		// TODO Auto-generated method stub

	}

	@Override
	public EmployeeBean searchEmployee(String empId) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		// cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from EmployeeBean");
		java.util.List<EmployeeBean> list = query.list();
		EmployeeBean empBean = null;
		for (EmployeeBean sb : list) {
			if (sb.getEmpId().equals(empId)) {
				empBean = sb;
				break;
			}
		}
		return empBean;
	}

}
