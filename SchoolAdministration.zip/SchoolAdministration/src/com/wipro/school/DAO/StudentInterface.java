package com.wipro.school.DAO;
import java.util.List;

import com.wipro.school.bean.StudentBean;

public interface StudentInterface
{
   public boolean updateStudent(StudentBean sb);
   public List<StudentBean> viewStudent(String registerId);
   public StudentBean searchStudent(String registerId);
} 
