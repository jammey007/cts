package com.wipro.school.DAO;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.wipro.school.bean.EmployeeBean;
import com.wipro.school.bean.StudentBean;

public class StudentDao implements StudentInterface {

	public boolean updateStudent(StudentBean sb) {
		boolean flag = false;
		try {
			Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
			SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();
			Transaction t = session.beginTransaction();
			session.update(sb);
			t.commit();
			session.close();
			factory.close();
			flag = true;
		} catch (HibernateException e) {
			flag = false;
		}
		return flag;
	}

	public List<StudentBean> viewStudent(String registerId) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		// cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from StudentBean");
		java.util.List<StudentBean> list = query.list();
		for (StudentBean sb : list) {
			System.out.println("Name:" + sb.getStudentName() + "\nregister id:" + sb.getRegisterId() + "\nuser name:"
					+ sb.getUserName() + "\npassword:" + sb.getPassword() + "\ndate of birth:" + sb.getDateOfBirth()
					+ "\nclass:" + sb.getStudentClass() + "\ndivision:" + sb.getDivision() + "\nfather name:"
					+ sb.getFatherName() + "\nmother name:" + sb.getMotherName() + "\n address:" + sb.getAddress()
					+ "\ncity:" + sb.getCity() + "\nstate:" + sb.getState() + "\npincode:" + sb.getPinCode()
					+ "\nstudent email:" + sb.getStudentEmail() + "\nstudent contact:" + sb.getStudentContact()
					+ "\nfather contact:" + sb.getFatherContact() + "\nmother contact:" + sb.getMotherContact()
					+ "\ngender:" + sb.getGender() + "\ncaste:" + sb.getCaste() + "\nreligion:" + sb.getReligion()
					+ "\nnationality:" + sb.getNationality() + "\nclass teacher:" + sb.getClassTeacher()
					+ "\namount paid:" + sb.getAmountPaid() + "\naccomodation:" + sb.getAccomodation() + "\ndistance:"
					+ sb.getDistance());
		}
		t.commit();
		session.close();
		return list;
	}

	@Override
	public StudentBean searchStudent(String registerId) {
		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
		// cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("from StudentBean");
		java.util.List<StudentBean> list = query.list();
		StudentBean stuBean=null;
		for(StudentBean sb:list) {
			if(sb.getRegisterId().equals(registerId)) {
				stuBean=sb;
				break;
			}
		}
		return stuBean;
	}



}
