package com.wipro.school.DAO;
import com.wipro.school.bean.EmployeeBean;

public interface EmployeeInterface 
{
  public boolean updateEmployee(EmployeeBean e);
  public void viewEmployee(String empId);
  public EmployeeBean searchEmployee(String empId);
}
