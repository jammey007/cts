package com.wipro.school.DAO;

import com.wipro.school.bean.FeesTypeBean;

public interface FeesInterface {
	public boolean updateFees(FeesTypeBean ftb);
}
