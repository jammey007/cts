package com.wipro.school.bean;

import javax.persistence.*;

@Entity
@Table(name="studentattendance")
public class StudentAttendanceBean {
	@Id
	private int serailNo;
	@Column(name="registerid")
	private String registerId;
	@Column(name="dayspresent")
	private int daysPresent;
	@Column(name="daysabsent")
	private int daysAbsent;
	@Column(name="totaldays")
	private int totalDays;
	private double average;

	public String getRegisterId() {
		return registerId;
	}

	public void setRegisterId(String registerId) {
		this.registerId = registerId;
	}

	public int getDaysPresent() {
		return daysPresent;
	}

	public void setDaysPresent(int daysPresent) {
		this.daysPresent = daysPresent;
	}

	public int getDaysAbsent() {
		return daysAbsent;
	}

	public void setDaysAbsent(int daysAbsent) {
		this.daysAbsent = daysAbsent;
	}

	public int getTotalDays() {
		return totalDays;
	}

	public void setTotalDays(int totalDays) {
		this.totalDays = totalDays;
	}

	public double getAverage() {
		return average;
	}

	public void setAverage(double average) {
		this.average = average;
	}

	public int getSerailNo() {
		return serailNo;
	}

	public void setSerailNo(int serailNo) {
		this.serailNo = serailNo;
	}

}
