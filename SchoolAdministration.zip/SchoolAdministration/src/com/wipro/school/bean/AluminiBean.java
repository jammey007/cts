package com.wipro.school.bean;

import java.sql.Date;

import javax.persistence.*;

@Entity
@Table(name = "alumini")
public class AluminiBean {
	@Id
	@Column(name = "registerid", nullable = false)
	private String registerId;
	@Column(name = "studentname", nullable = false)
	private String studentName;
	@Column(name = "dateofbirth", nullable = false)
	private Date dateOfBirth;
	@Column(name = "fathername", nullable = false)
	private String fatherName;
	@Column(name = "mothername", nullable = false)
	private String motherName;
	@Column(nullable = false)
	private String address;
	@Column(nullable = false)
	private String city;
	@Column(nullable = false)
	private String state;
	@Column(name = "pincode", nullable = false)
	private int pinCode;
	@Column(name = "studentemail")
	private String studentEmail;
	@Column(name = "studentcontact")
	private long studentContact;
	@Column(name = "fathercontact", nullable = false)
	private long fatherContact;
	@Column(name = "mothercontact", nullable = false)
	private long motherContact;
	@Column(nullable = false)
	private String gender;
	@Column(nullable = false)
	private String caste;
	@Column(nullable = false)
	private String religion;
	@Column(nullable = false)
	private String nationality;
	@Column(name = "passedout")
	private int passedOut;

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getRegisterId() {
		return registerId;
	}

	public void setRegisterId(String registerId) {
		this.registerId = registerId;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public long getStudentContact() {
		return studentContact;
	}

	public void setStudentContact(long studentContact) {
		this.studentContact = studentContact;
	}

	public long getFatherContact() {
		return fatherContact;
	}

	public void setFatherContact(long fatherContact) {
		this.fatherContact = fatherContact;
	}

	public long getMotherContact() {
		return motherContact;
	}

	public void setMotherContact(long motherContact) {
		this.motherContact = motherContact;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCaste() {
		return caste;
	}

	public void setCaste(String caste) {
		this.caste = caste;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public int getPassedOut() {
		return passedOut;
	}

	public void setPassedOut(int passedOut) {
		this.passedOut = passedOut;
	}
}
