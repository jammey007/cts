package com.wipro.school.bean;

import java.sql.Date;

import javax.persistence.*;
@Entity
@Table(name="newsfeed")
public class NewsFeedBean {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int serialNo;
	@Column(name="registerid")
	private String registerId;
	@Column(name="empid")
	private String empId;
	public int getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}

	public String getRegisterId() {
		return registerId;
	}

	public void setRegisterId(String registerId) {
		this.registerId = registerId;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	private String message;
	private Date sentDate;


	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getSentDate() {
		return sentDate;
	}

	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}
}
