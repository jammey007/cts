package com.wipro.school.bean;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

@Entity
@Table(name = "studenttimetable")
public class TimeTableBean {
	@Id
	@Column(name = "classdivision", nullable = false)
	private String classAndDivision;
	@Column(name = "pdffile", length=10000)
	private byte[] pdfFile;

	public String getClassAndDivision() {
		return classAndDivision;
	}

	public void setClassAndDivision(String classAndDivision) {
		this.classAndDivision = classAndDivision;
	}

	public byte[] getPdfFile() {
		return pdfFile;
	}

	public void setPdfFile(byte[] pdfFile) {
		this.pdfFile = pdfFile;
	}
}
