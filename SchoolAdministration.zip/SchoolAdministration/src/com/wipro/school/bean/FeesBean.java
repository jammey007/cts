package com.wipro.school.bean;

import java.sql.Date;

import javax.persistence.*;
@Entity
@Table(name="fees")
public class FeesBean {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int serialNo;
	@Column(name="studentclass")
	private int studentClass;
	@Column(name="feesamount")
	private double feesAmount;
	@Column(nullable=false)
	private int term;
	@Column(name="datewithoutfine")
	private Date dateWithoutFine;
	@Column(name="datewithfine")
	private Date dateWithFine;

	public int getStudentClass() {
		return studentClass;
	}

	public void setStudentClass(int studentClass) {
		this.studentClass = studentClass;
	}

	public double getFeesAmount() {
		return feesAmount;
	}

	public void setFeesAmount(double feesAmount) {
		this.feesAmount = feesAmount;
	}

	public int getTerm() {
		return term;
	}

	public void setTerm(int term) {
		this.term = term;
	}

	public Date getDateWithoutFine() {
		return dateWithoutFine;
	}

	public void setDateWithoutFine(Date dateWithoutFine) {
		this.dateWithoutFine = dateWithoutFine;
	}

	public Date getDateWithFine() {
		return dateWithFine;
	}

	public void setDateWithFine(Date dateWithFine) {
		this.dateWithFine = dateWithFine;
	}

	public int getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}
}
