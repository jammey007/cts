package com.wipro.school.bean;

import javax.persistence.Column;
import javax.persistence.*;

@Entity
@Table(name = "courses")
public class CoursesBean {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int serialNo;
	@Column(name = "registerId", nullable = false)
	private String registerId;
	@Column(name = "studentclass", nullable = false)
	private int StudentClass;
	@Column(name = "examtype", nullable = false)
	private String examType;
	@Column(nullable = false)
	private int subject1;
	@Column(nullable = false)
	private int subject2;
	@Column(nullable = false)
	private int subject3;
	@Column(nullable = false)
	private int subject4;
	@Column(nullable = false)
	private int subject5;
	@Column(nullable = false)
	private int subject6;
	@Column(nullable = false)
	private int subject7;
	@Column(nullable = false)
	private int subject8;
	@Column(nullable = false)
	private int subject9;
	@Column(nullable = false)
	private int subject10;
	@Column(nullable = false)
	private int subject11;
	@Column(nullable = false)
	private int subject12;

	public int getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}

	public String getRegisterId() {
		return registerId;
	}

	public void setRegisterId(String registerId) {
		this.registerId = registerId;
	}

	public int getStudentClass() {
		return StudentClass;
	}

	public void setStudentClass(int studentClass) {
		StudentClass = studentClass;
	}

	public String getExamType() {
		return examType;
	}

	public void setExamType(String examType) {
		this.examType = examType;
	}

	public int getSubject1() {
		return subject1;
	}

	public void setSubject1(int subject1) {
		this.subject1 = subject1;
	}

	public int getSubject2() {
		return subject2;
	}

	public void setSubject2(int subject2) {
		this.subject2 = subject2;
	}

	public int getSubject3() {
		return subject3;
	}

	public void setSubject3(int subject3) {
		this.subject3 = subject3;
	}

	public int getSubject4() {
		return subject4;
	}

	public void setSubject4(int subject4) {
		this.subject4 = subject4;
	}

	public int getSubject5() {
		return subject5;
	}

	public void setSubject5(int subject5) {
		this.subject5 = subject5;
	}

	public int getSubject6() {
		return subject6;
	}

	public void setSubject6(int subject6) {
		this.subject6 = subject6;
	}

	public int getSubject7() {
		return subject7;
	}

	public void setSubject7(int subject7) {
		this.subject7 = subject7;
	}

	public int getSubject8() {
		return subject8;
	}

	public void setSubject8(int subject8) {
		this.subject8 = subject8;
	}

	public int getSubject9() {
		return subject9;
	}

	public void setSubject9(int subject9) {
		this.subject9 = subject9;
	}

	public int getSubject10() {
		return subject10;
	}

	public void setSubject10(int subject10) {
		this.subject10 = subject10;
	}

	public int getSubject11() {
		return subject11;
	}

	public void setSubject11(int subject11) {
		this.subject11 = subject11;
	}

	public int getSubject12() {
		return subject12;
	}

	public void setSubject12(int subject12) {
		this.subject12 = subject12;
	}
}
