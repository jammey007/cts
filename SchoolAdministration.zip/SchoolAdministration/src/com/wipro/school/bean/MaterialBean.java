package com.wipro.school.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "materials")
public class MaterialBean {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@Column(name = "classdivision", nullable = false)
	private String classAndDivision;
	@Column(name = "pdffile", length = 100000)
	private byte[] pdfFile;
	private String subject;

	public String getClassAndDivision() {
		return classAndDivision;
	}

	public void setClassAndDivision(String classAndDivision) {
		this.classAndDivision = classAndDivision;
	}

	public byte[] getPdfFile() {
		return pdfFile;
	}

	public void setPdfFile(byte[] pdfFile) {
		this.pdfFile = pdfFile;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}
}
