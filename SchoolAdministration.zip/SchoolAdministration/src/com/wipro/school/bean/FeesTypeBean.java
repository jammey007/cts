package com.wipro.school.bean;

import javax.persistence.*;

@Entity
@Table(name = "feestype")
public class FeesTypeBean {
	@Id
	@Column(name = "studentclass")
	private String studentClass;
	@Column(name = "firstterm")
	private double firstTerm;
	@Column(name = "secondterm")
	private double secondTerm;
	@Column(name = "thirdterm")
	private double thirdTerm;
	@Column(name = "busfees")
	private double busFees;
	@Column(name = "hostelfees")
	private double hostelFees;

	public String getStudentClass() {
		return studentClass;
	}

	public void setStudentClass(String studentClass) {
		this.studentClass = studentClass;
	}

	public double getFirstTerm() {
		return firstTerm;
	}

	public void setFirstTerm(double firstTerm) {
		this.firstTerm = firstTerm;
	}

	public double getSecondTerm() {
		return secondTerm;
	}

	public void setSecondTerm(double secondTerm) {
		this.secondTerm = secondTerm;
	}

	public double getThirdTerm() {
		return thirdTerm;
	}

	public void setThirdTerm(double thirdTerm) {
		this.thirdTerm = thirdTerm;
	}

	public double getBusFees() {
		return busFees;
	}

	public void setBusFees(double busFees) {
		this.busFees = busFees;
	}

	public double getHostelFees() {
		return hostelFees;
	}

	public void setHostelFees(double hostelFees) {
		this.hostelFees = hostelFees;
	}
}
