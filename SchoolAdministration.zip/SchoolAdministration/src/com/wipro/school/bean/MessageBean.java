package com.wipro.school.bean;

import java.sql.Date;

import javax.persistence.*;

@Entity
@Table(name = "message")
public class MessageBean {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int serialNo;
	@Column(name = "empid")
	private String empId;
	@Column(name = "registerid")
	private String registerId;
	@Column(nullable = false)
	private String message;
	@Column(name = "sentdate", nullable = false)
	private Date sentDate;
	@Column(name = "fathercontact", nullable = false)
	private long fatherContact;
	@Column(name = "mothercontact", nullable = false)
	private long motherContact;

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getRegisterNumber() {
		return registerId;
	}

	public void setRegisterNumber(String registerId) {
		this.registerId = registerId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getSentDate() {
		return sentDate;
	}

	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}

	public long getFatherContact() {
		return fatherContact;
	}

	public void setFatherContact(long fatherContact) {
		this.fatherContact = fatherContact;
	}

	public long getMotherContact() {
		return motherContact;
	}

	public void setMotherContact(long motherContact) {
		this.motherContact = motherContact;
	}

	public int getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}
}
