import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionMapping;
import java.io.PrintWriter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class LoginAction extends org.apache.struts.action.Action
{
	public ActionForward execute(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response)throws Exception
	{
		System.out.println("in action");
	LoginForm lform=(LoginForm)form;
	response.setContentType("text/plain");
	PrintWriter out=response.getWriter();
	String us=lform.getUser();
	String ps=lform.getPassword();
	System.out.println(us+"   "+ps);
	if(us.equals(ps))
	{
		out.println("success");
	}
	else
	{
		out.println("failure");
	}
	return null;
	}
}