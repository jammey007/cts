import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

public class LoginForm extends org.apache.struts.action.ActionForm{
	
	private String user;
	private String password;
	
	public void setUser(String user)
	{
		this.user=user;
		System.out.println("in setter user"+user);
	}
	public String getUser()
	{
		System.out.println("in getter user"+user);
		return user;
		
	}
	public void setPassword(String password)
	{
		this.password=password;
			System.out.println("in setter "+password);
	}
	public String getPassword()
	{
		System.out.println("in getter "+password);
		return password;
		
	}
}