import React,{Component} from 'react';
import Chart1 from './chart1';
import Chart from './chart';
import _ from 'lodash';
import palette from 'color-palette';

//import CanvasJS from 'canvasjs';
let json=require('./receive.json');
var col=_.map(json,'Year');
console.log(col.length);
var data=_.map(json,'count');
let json1=require('./country.json');
var col1=_.map(json1,'COUNTRYSHORTNAME');
var data1=_.map(json1,'count1');
class App extends Component{
    constructor(){
        super();
        this.state={
            chartData:{},
            chartData1:{}
           
        }
   }
    componentWillMount(){
        this.getChartData();
        this.getChartData1();
        }
        
    getChartData(){
        this.setState({
            chartData:{
                labels:col,
                datasets:[
                    {
                        label:'index',
                        data:data,
                        backgroundColor: palette('tol', col.length).map(function(hex) {
                           //console.log( hex);
                           return hex;
                          }),
                        // borderColor: [
                        //     'rgba(255,99,132,1)',
                        //     'rgba(54, 162, 235, 1)',
                        //     'rgba(255, 206, 86, 1)',
                        //     'rgba(75, 192, 192, 1)',
                        //     'rgba(153, 102, 255, 1)',
                        //     'rgba(255, 159, 64, 1)'
                        // ],
                    }
                 ]
        }
        });
    }
    
    // getChartData1(){
    //     this.setState({
    //         chartData1:{
    //             labels:col1,
    //              datasets:[
    //                 {
    //                     label:'index',
    //                     data:data1,
    //                     // backgroundColor: palette('tol', col1.length).map(function(hex) {
    //                     //     return '#' + hex;
    //                     //   })
                        
    //                }
    //              ]
    //     }
    //     });
    // }
    render(){
        return(
            <div classname="App">
            <Chart chartData={this.state.chartData} legendPosition='right' string="APP RECEIVED INFO"/>
            <Chart1 chartData1={this.state.chartData1}  legendPosition='right' string="REGION POLICY COUNT"/>
            
            </div>
        )
    }
}
export default App;