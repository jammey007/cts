import React,{Component} from 'react';
import Chart2 from './chart2';
import Chart1 from './chart1';
import Chart from './chart';
import Home from './home';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import { Sidebar, SidebarItem } from 'react-responsive-sidebar';

// import {
//     Container,
//     Icon,
//     Image,
//     Menu,
//     Sidebar,
//     Responsive
//   } from "semantic-ui-react";
  
import _ from 'lodash';
let json=require('./receive.json');
var col=_.map(json,'Year');
var data=_.map(json,'count');
let json1=require('./country.json');
var col1=_.map(json1,'COUNTRYSHORTNAME');
var data1=_.map(json1,'count1');
let json2=require('./person.json');
var col2=_.map(json2,'SEX');
var data2=_.map(json2,'count2');
class App extends Component{
    constructor(){
        super();
        this.state={
            chartData:{},
            chartData1:{},
            chartData2:{}
           }
   }
    componentWillMount(){
        this.getChartData();
        this.getChartData1();
        this.getChartData2();
        }
    getChartData(){
        var min=0;
        var max=257;
        var color=[];
        for(let x=0;x<col.length;x++){
            let ran1=Math.floor(Math.random()*(max-min))+min;
            let ran2=Math.floor(Math.random()*(max-min))+min;
            let ran3=Math.floor(Math.random()*(max-min))+min;
            color[x]=`rgb(${ran1},${ran2},${ran3})`;
        }
        this.setState({
            chartData:{
                labels:col,
                datasets:[
                    {
                        label:'index',
                        data:data,
                        backgroundColor:color
                        
                    }
                 ]
        }
        });
    }
    
    getChartData1(){
        var min=0;
        var max=257;
        var color1=[];
        for(let x=0;x<col1.length;x++){
            let ran1=Math.floor(Math.random()*(max-min))+min;
            let ran2=Math.floor(Math.random()*(max-min))+min;
            let ran3=Math.floor(Math.random()*(max-min))+min;
            color1[x]=`rgb(${ran1},${ran2},${ran3})`;
        }
        this.setState({
            chartData1:{
                labels:col1,
                 datasets:[
                    {
                        label:'index',
                        data:data1,
                        backgroundColor: color1
                        
                   }
                 ]
        }
        });
    }
    getChartData2(){
        var min=0;
        var max=257;
        var color2=[];
        for(let x=0;x<col.length;x++){
            let ran1=Math.floor(Math.random()*(max-min))+min;
            let ran2=Math.floor(Math.random()*(max-min))+min;
            let ran3=Math.floor(Math.random()*(max-min))+min;
            color2[x]=`rgb(${ran1},${ran2},${ran3})`;
        }
        this.setState({
            chartData2:{
                labels:col2,
                 datasets:[
                    {
                        label:'index',
                        data:data2,
                        backgroundColor: color2
                        
                   }
                 ]
        }
        });
    }
    
    render(){
        const items = [
            <SidebarItem color="white" style={{textDecoration:'none'}}><Link to={'/'}>HOME</Link></SidebarItem>,
            <SidebarItem color="white"><Link to={'/chart'}>APP RECEIVED INFO</Link></SidebarItem>,
            <SidebarItem color="white"><Link to={'/chart1'}>REGIONAL POLICY DISTRIBUTION</Link></SidebarItem>,
            <SidebarItem color="white"><Link to={'/chart2'}>POLICY DISTRIBUTION</Link></SidebarItem>
         ];
        return(
                <div classname="App">
              <Router>
              <Sidebar content={items} background="black">
               <Switch>
                <Route exact path='/' component={() => <Home />}/>
                  <Route exact path='/chart' component={() => <Chart  chartData={this.state.chartData} legendPosition='right' string="APP RECEIVED INFO"/>} />
             <Route exact path='/chart1' component={() => <Chart1 chartData1={this.state.chartData1}  legendPosition='right' string="REGIONAL POLICY DISTRIBUTION"/>} />
                  <Route exact path='/chart2' component={() => <Chart2 chartData2={this.state.chartData2}  legendPosition='right' string="POLICY DISTRIBUTION"/>}  />
               </Switch>
            </Sidebar>
            </Router>
         </div>
        )
    }
}
export default App;