import React,{Component} from 'react';
import {Pie} from 'react-chartjs-2';
import './App';
class chart extends Component{
    
    constructor(props){
        super(props);
        this.state={
            chartData:props.chartData
        }
       
         }
        static defaultProps={
           displayTitle:true,
           legendPosition:'left',
            displayLegend:true,
           }
    
    render(){
        return(
            <div className="chart"  >
            <header style={{ height:'50px', textAlign:'center'}}>
                <h1>Insurance</h1>
            </header>
            <Pie
               data={this.state.chartData}
               width={500}
               height={300}
              
               options={{
               
                   maintainAspectRatio:false,
                   title:{
                    display:this.props.displayTitle,
                    text   :this.props.string,
                    },
                    legend:{
                        display:this.props.displayLegend,
                        position:this.props.legendPosition
                    } 
                    
                   }}
               />                
        </div>
           
        )
    }
}
export default chart;