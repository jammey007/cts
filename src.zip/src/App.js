import React,{Component} from 'react';
import './App.css';
import Chart from './chart';
class App extends Component{
    constructor(){
        super();
        this.state={
            chartData:{}
        }
    }
    componentWillMount(){
        this.getChartData();
    }
    getChartData(){
        this.setState({
            chartData:{
                labels:['A','B','C','D','E','F','G','H','I','J','K','L'],
                datasets:[
                    {
                        label:'index',
                        data:[
                            1,
                            2,
                            3,
                            4,
                            5,6,7,8,9,10,11,12
                        ],
                        backgroundColor:[
                            'rgb(0,0,0)',
                            'rgb(0,0,255)',
                            'rgb(223,222,333)',
                            'rgb(222,99,33)',
                            'rgb(33,44,33)',
                            'rgb(555,55,4)',
                            'rgb(0,334,0)',
                            'rgb(0,90,0)',
                            'rgb(42,0,0)',
                            'rgb(123,0,0)',
                            'rgb(221,221,0)',
                            'rgb(225,0,0)',

                        ]
                    }
                ]
        }
        });
    }
    render(){
        return(
            <div classname="App">
          
            <Chart chartData={this.state.chartData} string="Alphabets Index" legendPosition='bottom'/>
            {/* <Chart chartData={this.state.chartData}  legendPosition='right'/> */}
            </div>
        )
    }
}
export default App;