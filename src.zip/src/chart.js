import React,{Component} from 'react';
import {Bar,Line,Pie} from 'react-chartjs-2';
import './App';
class chart extends Component{
    constructor(props){
        super(props);
        this.state={
            chartData:props.chartData
        }

        }
        static defaultProps={
            displayTitle:true,
            legendPosition:'right',
            displayLegend:true,
            string:'tit'

        }
    
    render(){
        return(
            <div className="chart"  >
            
               <Bar
               data={this.state.chartData}
               options={{
                   maintainAspectRatio:true,
                   title:{
                       display:this.props.displayTitle,
                       text:this.props.string,
                       fontsize:25
                   },
                  legend:{
                      display:this.props.displayLegend,
                      position:this.props.legendPosition
                  } 
               }}
               />
               <Line
               data={this.state.chartData}
               options={{
                   maintainAspectRatio:true,
                   title:{
                       display:this.props.displayTitle,
                       text:this.props.string,
                       fontsize:25
                   },
                  legend:{
                      display:this.props.displayLegend,
                      position:this.props.legendPosition
                  } 
               }}
               />
               <Pie
               data={this.state.chartData}
               options={{
                   maintainAspectRatio:true,
                   title:{
                       display:this.props.displayTitle,
                       text:this.props.string,
                       fontsize:25
                   },
                  legend:{
                      display:this.props.displayLegend,
                      position:this.props.legendPosition
                  } 
               }}
               />
                  
                  
            </div>
           
        )
    }
}
export default chart;